<script setup>
const props = defineProps({
    text: {
        type: String,
        required: true
    },

});


</script>

<template>
    <div class="d-flex">
        {{ text }}

        <img src="../assets/icon/arrow-right.png" width="24" max-height="24" contain></img>
    </div>

</template>