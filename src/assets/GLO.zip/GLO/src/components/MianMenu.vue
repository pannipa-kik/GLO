<template>
    <v-app-bar :elevation="2" class="ps-5 pe-5">
        <v-img
            src="../assets/image 332.png"
            max-width="40"
            max-height="40"
            contain
        ></v-img>
        <v-app-bar-title class="ml-2">
            <ul>
                <li>หน้าหลัก</li>
                <li>เกี่ยวกับเรา</li>
                <li>ข่าวสาร</li>
                <li>ข่าวสาร</li>
                <li>ข่าวสาร</li>
                <li>ข่าวสาร</li>
                <li>ข่าวสาร</li>
            </ul>
        </v-app-bar-title>
        <v-btn class="bg_primary_ฺblue text-white">
            เข้าสู่ระบบ/ลงทะเบียน
        </v-btn> 
    </v-app-bar>
</template>


<style scoped lang="scss">
ul{
    display: flex !important;
    margin-left: 15px;
    li{
    list-style-type: none !important; /* ปิดการแสดงผลจุดจากรายการ */
    padding: 0; /* ปิดการ padding */
    margin-left: 15px;
    }

}
</style>