// data.js

import propertyImage from '../assets/Image.png';

export const cardData = [
    {
        author: "พิมพ์ใจ ดวงใจ",
      date: "25/07/2024",
      views: 20,
      likes: 22,
      saves: 22,
      title: "หลักสูตรสร้างโอกาสแห่งความสุขที่ยั่งยืนหลักสูตรสร้างโอกาสแห่งความสุขที่ยั่งยืนยืนหลักสูตรสร้างโอกาส",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
      chipText: "ภารกิจสนับสนุน",
      avatarSrc: propertyImage ,
    },
    {
        author: "พิมพ์ใจ ดวงใจ",
      date: "25/07/2024",
      views: 20,
      likes: 22,
      saves: 22,
      title: "หลักสูตรสร้างโอกาสแห่งความสุขที่ยั่งยืนหลักสูตรสร้างโอกาสแห่งความสุขที่ยั่งยืนยืนหลักสูตรสร้างโอกาส",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
      chipText: "ภารกิจสนับสนุน",
      avatarSrc: propertyImage ,
    },

    {
        author: "พิมพ์ใจ ดวงใจ",
      date: "25/07/2024",
      views: 20,
      likes: 22,
      saves: 22,
      title: "หลักสูตรสร้างโอกาสแห่งความสุขที่ยั่งยืนหลักสูตรสร้างโอกาสแห่งความสุขที่ยั่งยืนยืนหลักสูตรสร้างโอกาส",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
      chipText: "ภารกิจสนับสนุน",
      avatarSrc: propertyImage ,
    },


  ];
  