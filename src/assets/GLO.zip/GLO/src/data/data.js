// data.js

import propertyImage from '../assets/Image.png';

export const cardData = [
    {
      name: "พิมพ์ใจ ดวงใจ",
      date: "25/07/2024",
      views: 20,
      likes: 22,
      saves: 22,
      title: "หลักสูตรสร้างโอกาสแห่งความสุขที่ยั่งยืน",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
      chip: "ภารกิจสนับสนุน",
      imageSrc: propertyImage,  
      avatarSrc: propertyImage  
    },
    {
        name: "พิมพ์ใจ ดวงใจ",
        date: "25/07/2024",
        views: 20,
        likes: 22,
        saves: 22,
        title: "หลักสูตรสร้างโอกาสแห่งความสุขที่ยั่งยืน",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
        chip: "ภารกิจหลัก",
        imageSrc: propertyImage,  
        avatarSrc: propertyImage  
      },
      {
        name: "พิมพ์ใจ ดวงใจ",
        date: "25/07/2024",
        views: 20,
        likes: 22,
        saves: 22,
        title: "หลักสูตรสร้างโอกาสแห่งความสุขที่ยั่งยืน",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
        chip: "ภารกิจสนับสนุน",
        imageSrc: propertyImage,  
        avatarSrc: propertyImage  
      },
      {
        name: "พิมพ์ใจ ดวงใจ",
        date: "25/07/2024",
        views: 20,
        likes: 22,
        saves: 22,
        title: "หลักสูตรสร้างโอกาสแห่งความสุขที่ยั่งยืน",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
        chip: "ภารกิจสนับสนุน",
        imageSrc: propertyImage,  
        avatarSrc: propertyImage  
      },
      {
        name: "พิมพ์ใจ ดวงใจ",
        date: "25/07/2024",
        views: 20,
        likes: 22,
        saves: 22,
        title: "หลักสูตรสร้างโอกาสแห่งความสุขที่ยั่งยืน",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
        chip: "ภารกิจสนับสนุน",
        imageSrc: propertyImage,  
        avatarSrc: propertyImage  
      },
      {
        name: "พิมพ์ใจ ดวงใจ",
        date: "25/07/2024",
        views: 20,
        likes: 22,
        saves: 22,
        title: "หลักสูตรสร้างโอกาสแห่งความสุขที่ยั่งยืน",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
        chip: "ภารกิจสนับสนุน",
        imageSrc: propertyImage,  
        avatarSrc: propertyImage  
      },
      {
        name: "พิมพ์ใจ ดวงใจ",
        date: "25/07/2024",
        views: 20,
        likes: 22,
        saves: 22,
        title: "หลักสูตรสร้างโอกาสแห่งความสุขที่ยั่งยืน",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
        chip: "ภารกิจสนับสนุน",
        imageSrc: propertyImage,  
        avatarSrc: propertyImage  
      },
      {
        name: "พิมพ์ใจ ดวงใจ",
        date: "25/07/2024",
        views: 20,
        likes: 22,
        saves: 22,
        title: "หลักสูตรสร้างโอกาสแห่งความสุขที่ยั่งยืน",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
        chip: "ภารกิจสนับสนุน",
        imageSrc: propertyImage,  
        avatarSrc: propertyImage  
      },
      {
        name: "พิมพ์ใจ ดวงใจ",
        date: "25/07/2024",
        views: 20,
        likes: 22,
        saves: 22,
        title: "หลักสูตรสร้างโอกาสแห่งความสุขที่ยั่งยืน",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
        chip: "ภารกิจสนับสนุน",
        imageSrc: propertyImage,  
        avatarSrc: propertyImage  
      },
  ];
  