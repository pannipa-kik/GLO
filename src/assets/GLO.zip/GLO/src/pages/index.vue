<script setup>
import sectionSarvices from '../views/home/sectionSarvices.vue'
import sectionKnowledgeBase from '../views/home/sectionKnowledgeBase.vue'
import sectionPressRelease from '../views/home/sectionPressRelease.vue'
import sectionStatistics from '../views/home/sectionStatistics.vue'
import sectionEventCalendar from '../views/home/sectionEventCalendar.vue'
import sectionLeaderBoard from '../views/home/sectionLeaderBoard.vue'
import sectionRecommendedKnowledge from '../views/home/sectionRecommendedKnowledge.vue'
</script>


<template>
  <v-container>
    <div class="box-head">
      <img src="../assets/Isolation_Mode.png" width="266" max-height="88" contain></img>
      <h1 class="primary_ฺblue mt-3">Innovation & Knowledge space : i-Know</h1>
      <p class="primary_ฺamber">The Government Lottery Office </p>
      <img src="../assets/index-head.png" width="400" max-height="330" contain class="index-head-img"></img>
    </div>
    <sectionSarvices />
    <sectionLeaderBoard />
  </v-container>
  <sectionRecommendedKnowledge />
  <sectionKnowledgeBase />
  <sectionPressRelease />
  <sectionEventCalendar />
  <sectionStatistics />

  <div class="image-top-left">
    <img src="../assets/bg-index-top.png" max-width="500" height="800"></img>
  </div>

  <div class="image-top-left-2">
    <img src="../assets/bg-index-top2.png" max-width="500" height="800"></img>
  </div>

  <div class="image-bottom-left">
    <img src="../assets/bg-index-botton.png" max-width="300" height="400"></img>
  </div>
</template>


<style scoped lang="scss">
.box-head {
  margin-top: 133px;
  position: relative;

  .index-head-img {
    right: 0;
    top: -120px;
    position: absolute;
  }

}

.image-top-left-2 img {
  position: absolute !important;
  top: 6% !important;
  right: 0 !important;
  z-index: 0;
}

.image-top-left img {
  position: absolute !important;
  top: 0 !important;
  left: 0 !important;
}

.image-bottom-left img {
  position: absolute !important;
  bottom: 215px !important;
  left: 0 !important;
  z-index: 0;
}
</style>
