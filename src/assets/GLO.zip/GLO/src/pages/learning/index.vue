<script setup>
import { ref } from 'vue';
import cardELearning from '../../views/e_learning/index'


const text = ref('left')
const selectedChip = ref(null);
const value = ref(0)

</script>


<template>
    <div class="image-top-left">
        <img src="../../assets/VectorG1.png" max-width="300" height="300"></img>
    </div>
    <div class="image-top-right">
        <img src="../../assets/VectorG2.png" max-width="300" height="1000"></img>
    </div>
    <v-container class="fill-height text-white">
        <v-container>
            <div style="margin-top: 141px;">
                <h1 class="primary_ฺblue">ระบบการเรียนออนไลน์ (e-Learning)</h1>
                <p class="primary_ฺamber">Innovation & Knowledge space : i-Know</p>
                <div class="  bg_secondary_grey2 box-button">
                    <v-btn-toggle v-model="text" color="deep-purple-accent-3" rounded="0" group>
                        <v-btn value="left">
                            ล่าสุด
                        </v-btn>

                        <v-btn value="center">
                            แนะนำ
                        </v-btn>

                        <v-btn value="right">
                            ยอดนิยม
                        </v-btn>
                    </v-btn-toggle>
                </div>
                <div class="search ">
                    <v-text-field prepend-inner-icon="mdi-magnify" density="compact" label="ค้นหา" variant="solo"
                        hide-details single-line></v-text-field>
                    <v-btn class="text-white ms-5">
                        ค้นหาข้อมูล
                    </v-btn>
                </div>
                <div class="filter">
                    <v-layout class="overflow-visible" style="height: 56px;">
                        <v-bottom-navigation v-model="value" active>
                            <v-btn>ภารกิจจำหน่าย</v-btn>
                            <v-btn>ภารกิจการพิมพ์</v-btn>
                            <v-btn>กองควบคุมคุณภาพ</v-btn>
                            <v-btn>กองออกรางวัล</v-btn>
                            <v-btn>งานสลาก</v-btn>
                            <v-btn>CG</v-btn>
                        </v-bottom-navigation>
                    </v-layout>
                </div>
                <div>
                    <cardELearning />
                </div>
            </div>
        </v-container>
    </v-container>

</template>

<style lang="scss" scoped>
.filter {
    margin-top: 20px !important;
    display: flex;
    justify-content: center;

    .v-btn--active {
        background-color: #0033A1;
        color: #fff !important;
    }

    .v-bottom-navigation {
        background-color: transparent;
        box-shadow: none;
    }

    .v-bottom-navigation .v-bottom-navigation__content>.v-btn {
        border: 1px solid;
        margin: 0px 5px;
        border-radius: 8px;
        height: 38px;
        color: #0033A1;
    }

}

.search {
    margin-top: 20px !important;
    height: 40px !important;
    display: flex;
    justify-content: center;
    align-items: center;
    width: 695px;
    margin: 0 auto;

    ::v-deep .v-field--variant-solo {
        box-shadow: none !important;

    }

    ::v-deep .v-input__control {
        border: 1px solid #E2E2E2;
        border-radius: 8px;

    }

    .v-btn--variant-elevated {
        background: #0033A1 !important;
        width: 95px;
        border-radius: 8px;
        padding: 0 16px;

    }
}


.box-button {
    width: 280px;
    margin: 0 auto;
    border-radius: 12px;
    padding: 0 20px;
    margin-top: 30px;
    height: 50px;
    display: flex;
    align-items: center;
}

.v-btn--variant-elevated {
    background-color: #F5F5F5 !important;
}

.bg-deep-purple-accent-3 {
    color: #0033A1 !important;
    border-radius: 12px !important;
}

.v-btn-group--density-default.v-btn-group {
    height: 35px;
}

.image-top-left img {
    position: absolute !important;
    top: 10px !important;
    left: 0 !important;
}

.image-top-right img {
    position: absolute !important;
    top: 15px !important;
    right: 0;

}

</style>
