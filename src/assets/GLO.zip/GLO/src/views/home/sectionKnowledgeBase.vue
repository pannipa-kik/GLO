<script setup>
import { ref } from 'vue';
import { Carousel, Navigation, Slide } from 'vue3-carousel';
import 'vue3-carousel/dist/carousel.css';
import promote from '../../assets/promote.png';

const slides = [
    {
        imgSrc: promote,
        title: "หลักสูตรสร้างโอกาสแห่งความสุขที่ยั่งยืน",
        description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
        author: "ธัญญารัตน์ อดิศัย",
        date: "25/07/2024",
        views: 20,
    },
    {
        imgSrc: promote,
        title: "หลักสูตรพัฒนาทักษะการทำงาน",
        description:
            "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
        author: "สมชาย แก้วมณี",
        date: "01/08/2024",
        views: 50,
    },
    {
        imgSrc: promote,
        title: "หลักสูตรฝึกฝนทักษะการเรียนรู้",
        description:
            "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
        author: "พรทิพย์ รุ่งโรจน์",
        date: "15/09/2024",
        views: 30,
    },
    {
        imgSrc: promote,
        title: "หลักสูตรฝึกฝนทักษะการเรียนรู้",
        description:
            "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
        author: "พรทิพย์ รุ่งโรจน์",
        date: "15/09/2024",
        views: 30,
    },
];
</script>

<template>
    <div class="position-relative">
        <div class="image-top-left">
            <img src="../../assets/bg-knowledge.png" max-width="100" height="100"></img>
        </div>
        <div class="image-top-right">
            <img src="../../assets/bg-knowledge2.png" max-width="300" height="500"></img>
        </div>
        <v-container>
            <div style="margin-top: 30px;" class="d-flex align-center justify-space-between">
                <MainTopic text="คอร์สแนะนำ" />
                <All text="ดูทั้งหมด" />
            </div>
        </v-container>
        <Carousel :items-to-show="2.5" :wrap-around="true">
            <Slide v-for="(slide, index) in slides" :key="index">
                <div class="carousel__item">
                    <dic class="mx-8 my-8" elevation="16" max-width="600">
                        <img :src="slide.imgSrc" width="100%" />
                        <div class="box-card">
                            <v-chip size="x-small" :class="chipClass" type="button" class="mt-3">
                                ภารกิจสนับสนุน </v-chip>
                            <h3 class="primary_ฺblue ">{{ slide.title }}</h3>
                            <p class="mt-3">{{ slide.description }}</p>
                            <div class="d-flex align-center justify-space-between">
                                <div class="d-flex align-center justify-space-start mt-3 mb-3">
                                    <div class="d-flex align-center ga-2 box-Action">
                                        <div class="d-flex align-center">
                                            <v-avatar>
                                                <v-img src="../../assets/image.png" alt="avatar"></v-img>
                                            </v-avatar>
                                            <span class="ms-2 primary_ฺblue">{{ slide.author }}</span>
                                        </div>
                                        <div class="d-flex align-center">
                                            <v-img alt="calendar" src="../../assets/icon/calendar.png" width="16"
                                                max-height="16"></v-img>
                                            <span class="ms-1">{{ slide.date }}</span>
                                        </div>
                                        <div class="d-flex align-center">
                                            <v-img alt="eye" src="../../assets/icon/eye.png" width="16"
                                                max-height="16"></v-img>
                                            <span class="ms-1">{{ slide.views }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="ms-2">
                                    <v-img alt="archive add" src="../../assets/icon/archive-add.png" width="32"
                                        max-height="32"></v-img>
                                </div>
                            </div>
                        </div>
                    </dic>
                </div>
            </Slide>

            <template #addons>
                <Navigation />
            </template>
        </Carousel>
    </div>
</template>

<style scoped lang="scss">
.carousel__item {
    display: flex;
    justify-content: center;
    align-items: center;
}

.carousel {
    text-align: left;
}


.primary_ฺblue {
    color: #1976D2;
    /* Primary blue color */
}

.ga-2 {
    gap: 10px;
}


.carousel__slide {

    /* ตั้งค่าค่าเริ่มต้นของ slide ที่ไม่ active */
    .box-card {
        display: none;
        /* ซ่อน box-card ถ้า slide ไม่ active */
    }

    img {
        /* ตั้งค่า margin-top ของภาพใน slide ที่ไม่ active */
        transition: margin-top 0.3s ease;
        /* เพิ่ม transition เพื่อให้การเปลี่ยนแปลง smooth */
    }
}

.carousel__slide--active {

    /* ตั้งค่า margin-top ของ slide ที่ active */
    .box-card {
        display: block;
        /* ซ่อน box-card ถ้า slide ไม่ active */
    }

    img {
        margin-top: 50px;
        /* ตั้งค่า margin-top ของภาพใน slide ที่ active */
    }
}

.image-top-left img {
    position: absolute !important;

    bottom: 7px !important;
    left: 100px !important;
}

.image-top-right img {
    position: absolute !important;

    bottom: 7px !important;
    right: 0 !important;
}
</style>
