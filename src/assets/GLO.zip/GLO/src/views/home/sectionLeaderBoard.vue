<script setup lang="ts">
import { ref } from 'vue';

// Reactive reference for active tab state
const tab = ref(0); // 0 means the first tab is active by default
const getRankColor = (rank: number) => {
    if (rank === 1) return 'default-bg  ';
    if (rank === 2) return 'pink-bg ';
    if (rank === 3) return 'green-bg';
    return '';
};
// Mock user data
const users = [
    { rank: 1, username: 'กฤติธัช จิตราพรชัยวัฒน์', points: 11238 },
    { rank: 2, username: 'สุธารัตน์ อักษรสวัสดิ์', points: 10294 },
    { rank: 3, username: 'สมชาย สายทองคำ', points: 9875 },
    { rank: 4, username: 'พิทักษ์ ภูวงศ์', points: 8764 },
    { rank: 5, username: 'มาลี อินทรีย์', points: 8650 },
    { rank: 6, username: 'นพดล จันทรพานิช', points: 8125 },
    { rank: 7, username: 'วรรณิภา รัตนวงศ์', points: 7623 },
    { rank: 8, username: 'อนุชา อภิรักษ์', points: 7541 },
    { rank: 9, username: 'อรทัย ศิริวัฒน์', points: 7289 },
    { rank: 10, username: 'ภูมิภัทร ทรงศรี', points: 7012 },
];
</script>

<template>
    <v-container>
        <div style="margin-top: 60px;">
            <MainTopic text="Leader Board" />
        </div>
        <div class="box-tabs mt-5">
            <v-row>
                <v-col cols="12" md="6" sm="6">
                    <img  src="../../assets/Board.png" width="100%"/>
                </v-col>
                <v-col cols="12" md="6" sm="6">
                    <v-tabs v-model="tab">
                        <v-tab value="one">ผู้รู้ยอดนิยม</v-tab>
                        <v-tab value="two">ผู้เรียนยอดนิยม</v-tab>
                    </v-tabs>
                    <v-tabs-window v-model="tab">
                        <v-tabs-window-item value="one">
                            <div>
                                <div class="mt-4 mb-4">
                                    <h4>ข้อมูลผู้รู้ยอดนิยมประจำเดือนสิงหาคม</h4>
                                </div>
                                <div >
                                    <v-row>
                                        <v-col cols="2">#</v-col>
                                        <v-col cols="8">Username</v-col>
                                        <v-col cols="2">Points</v-col>
                                    </v-row>
                                </div>
                                <div class="mt-5 scrollable-list" >
                                    <div style="  margin-top: 25px;">
                                    <v-row v-for="user in users" :key="user.rank">
                                        <v-col cols="2">
                                            <div :class="getRankColor(user.rank)" class="number">
                                                <h3 class="mt-5 mb-5">{{ user.rank }}</h3>
                                            </div>
                                        </v-col>
                                        <v-col cols="8">
                                            <p class="">{{ user.username }}</p>
                                        </v-col>
                                        <v-col cols="2">
                                            <p class="">{{ user.points }} <span>pt</span></p>
                                        </v-col>
                                    </v-row>
                                </div>
                                </div>
                            </div>
                        </v-tabs-window-item>
                        <v-tabs-window-item value="two">
                            Two
                        </v-tabs-window-item>
                    </v-tabs-window>
                </v-col>
            </v-row>
        </div>
    </v-container>
</template>

<style lang="scss" scoped>

::v-deep .v-slide-group__content {
    background-color: white;
    color: black;
}

.scrollable-list {
        max-height: 300px; 
        overflow-y: auto; 
        padding-right: 15px; 
    }

.box-tabs {
    .v-window-item {
        max-height: 482px;
        height: 482px;
    }
    .number {
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        height: 32px;
        width: 32px;
        color: black;
        background-color: #F5F5F5;

    }

    .default-bg {
        background-color: #fd9b3a;
        color: white;
        max-height: 80px;
        height: 32px;
        width: 32px;
        position: relative;
        // margin-top: 25px;

        &::before {
            content: "";
            position: absolute;
            left: 2px;
            top: -15px;
            transform: translateY(-49%);
            height: 20px;
            width: 26px;
            background-image: url(/src/assets/1.png);
            background-size: cover;
            background-repeat: no-repeat;
         
        }
    }

    .pink-bg {
        background-color: #FE6A7C;
        color: white;

    }

    .green-bg {
        background-color: #00C6BE;
        color: white;
    }

}
</style>
