<script setup>
import promote from '../../assets/promote1.png';


</script>


<template>
    <v-container>
        <div style="margin-top: 50px;" class="d-flex align-center justify-space-between">
            <MainTopic text="ข่าวประชาสัมพันธ์" />
            <All text="ดูทั้งหมด" />
        </div>

        <div class="mt-5">
            <v-row>
                <v-col cols="12" md="6" sm="12">
                    <div class="box-card">
                        <v-card>
                            <img :src="promote" width="100%" contain></img>
                            <v-row>
                                <v-col cols="12" md="12" sm='6'>
                                    <div class="box-content">
                                        <h3 class="primary_ฺblue mb-2">ขอเชิญชวนทุกท่าน
                                            มาร่วมให้สิ่งแวดล้อมที่ดี...เพื่อเราทุกคน กับ กิจกรรม “GLO Give Green”</h3>
                                        <p>ราเมนพริตตี้รีวิว ดั๊มพ์ตังค์เอสเปรสโซ
                                            คาสิโนรีวิวสเปกตุ๊กตุ๊กเพนกวินแจ็กพ็อตโมเต็ลไหร่ยาวี ชิฟฟอนเหี่ยวย่น
                                            คำสาปมุมมองมินท์ปิยมิตรตื้บ</p>
                                        <div class="d-flex align-center justify-space-between">
                                            <div class="d-flex align-center justify-space-start mt-3 mb-3">
                                                <div class="d-flex align-center ga-2 box-Action">
                                                    <div class="d-flex align-center">
                                                        <v-img alt="calendar" src="../../assets/icon/calendar.png"
                                                            width="16" max-height="16"></v-img>
                                                        <span class="ms-1">25/07/2024</span>
                                                    </div>
                                                    <div class="d-flex align-center">
                                                        <v-img alt="eye" src="../../assets/icon/eye.png" width="16"
                                                            max-height="16"></v-img>
                                                        <span class="ms-1">22</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </v-col>
                            </v-row>
                        </v-card>
                    </div>
                </v-col>
                <v-col cols="12" md="6" sm="12">
                    <v-row>
                        <v-col cols="12" md="12" sm='12'>
                            <div class="card-horizontal">
                                <v-card>
                                    <v-row>
                                        <v-col cols="12" md="6" sm="12">
                                            <v-img :src="promote" alt="Event image" height="100%" />
                                        </v-col>
                                        <!-- Content Section -->
                                        <v-col cols="12" md="6" sm="12">
                                            <div class="pa-2">
                                                <h4 class="text-primary mb-2">ขอเชิญชวนทุกท่าน มาร่วมให้สิ่งแวดล้อมที่ดี
                                                </h4>
                                                <span>
                                                    โดนักเวิร์ลด์ เด้อ อัลไซเมอร์น็อค ออร์เดอร์ซิฟฟอนปูอัดสันทนาการ
                                                </span>
                                                <div class="d-flex align-center justify-space-between">
                                                    <div class="d-flex align-center justify-space-start mt-3 mb-3">
                                                        <div class="d-flex align-center ga-2 box-Action">
                                                            <div class="d-flex align-center">
                                                                <v-img alt="calendar"
                                                                    src="../../assets/icon/calendar.png" width="16"
                                                                    max-height="16"></v-img>
                                                                <span class="ms-1">25/07/2024</span>
                                                            </div>
                                                            <div class="d-flex align-center">
                                                                <v-img alt="eye" src="../../assets/icon/eye.png"
                                                                    width="16" max-height="16"></v-img>
                                                                <span class="ms-1">22</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </v-col>
                                    </v-row>
                                </v-card>
                            </div>
                        </v-col>
                    </v-row>
                </v-col>
            </v-row>
        </div>
    </v-container>
</template>


<style scoped lang="scss">
::v-deep .v-img__img--contain {
    object-fit: cover !important;

}

.card-horizontal {
    ::v-deep .v-card--variant-elevated {
        // padding: 15px;
        border-radius: 12px;
    }
}

.box-card {
    .box-content {

        padding: 15px;
    }

    span {
        font-size: 12px;
    }

    .v-card--variant-elevated {
        // padding: 15px;
        border-radius: 12px;
    }

    .v-avatar {
        width: 16px;
        height: 16px;
    }

}
</style>