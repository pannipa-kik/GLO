<script setup>
import { ref } from 'vue';
import { Carousel, Navigation, Slide } from 'vue3-carousel';
import 'vue3-carousel/dist/carousel.css';
import promote from '../../assets/promote1.png';


const slides = [
    {
        imgSrc: promote,
        title: "หลักสูตรสร้างโอกาสแห่งความสุขที่ยั่งยืน",
        description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
        author: "ธัญญารัตน์ อดิศัย",
        date: "25/07/2024",
        views: 20,
    },
    {
        imgSrc: promote,
        title: "หลักสูตรพัฒนาทักษะการทำงาน",
        description:
            "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
        author: "สมชาย แก้วมณี",
        date: "01/08/2024",
        views: 50,
    },
    {
        imgSrc: promote,
        title: "หลักสูตรฝึกฝนทักษะการเรียนรู้",
        description:
            "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
        author: "พรทิพย์ รุ่งโรจน์",
        date: "15/09/2024",
        views: 30,
    },
    {
        imgSrc: promote,
        title: "หลักสูตรฝึกฝนทักษะการเรียนรู้",
        description:
            "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
        author: "พรทิพย์ รุ่งโรจน์",
        date: "15/09/2024",
        views: 30,
    },
];
</script>

<template>
    <v-container>
        <div style="margin-top: 30px;" class="d-flex align-center justify-space-between">
            <MainTopic text="คลังความรู้ที่แนะนำ" />
            <All text="ดูทั้งหมด" />
        </div>
    </v-container>
    <Carousel :items-to-show="2.5" :wrap-around="true">
        <Slide v-for="(slide, index) in slides" :key="index">
            <div class="carousel__item">
                <dic class=" my-8" elevation="16" max-width="600">
                    <div class="box-card">
                        <v-card class="my-8" elevation="16">
                            <v-row>
                                <v-col cols="12" md="6" sm="12">
                                    <img :src="promote" alt="Event image" height="100%" />
                                </v-col>
                                <!-- Content Section -->
                                <v-col cols="12" md="6" sm="12">
                                    <div class="pa-2 ms-5 mt-5 me-5">
                                        <div class="d-flex align-center">
                                            <v-avatar class="mb-3">
                                                <img :src="promote" alt="avatar"></img>
                                            </v-avatar>
                                            <span class="ms-2 primary_ฺblue">ชยาภา ชุมชอบ</span>
                                        </div>


                                        <h4 class="text-primary mb-2">ขอเชิญชวนทุกท่าน มาร่วมให้สิ่งแวดล้อมที่ดี
                                        </h4>
                                        <span>
                                            ไฮแจ็คนอมินีลดตัวซาบะรับช่วง ไฮแจ็ค แซวรัชทายาทพาสตางอหายฮันนีมูนลูกรังแฟรี่
                                            รวบยอดวางตาป๊อปนอนก้น ทนายความปลดปล่อยนพศูลฉุนเฉียวเหนื่อยหน่าย
                                        </span>
                                        <div class="d-flex align-center justify-space-between"
                                            style="margin-top: 50px;">
                                            <div class="d-flex align-center justify-space-start mt-3 mb-3">
                                                <div class="d-flex align-center ga-2 box-Action">
                                                    <div class="d-flex align-center">
                                                        <v-img alt="calendar" src="../../assets/icon/calendar.png"
                                                            width="16" max-height="16"></v-img>
                                                        <span class="ms-1">25/07/2024</span>
                                                    </div>
                                                    <div class="d-flex align-center">
                                                        <v-img alt="eye" src="../../assets/icon/eye.png" width="16"
                                                            max-height="16"></v-img>
                                                        <span class="ms-1">22</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </v-col>
                            </v-row>
                        </v-card>
                    </div>
                </dic>
            </div>
        </Slide>

        <template #addons>
            <Navigation />
        </template>
    </Carousel>
</template>

<style scoped lang="scss">
.carousel__item {
    display: flex;
    justify-content: center;
    align-items: center;
}

.carousel {
    text-align: left;
}


.primary_ฺblue {
    color: #1976D2;
    /* Primary blue color */
}

.ga-2 {
    gap: 10px;
}

.v-card {
    border-radius: 12px;
}

.carousel__slide {
    flex: 0 0 auto;
    /* ให้สไลด์ไม่ยืดออกเต็มที่ */
    display: flex;
    justify-content: center;
    align-items: center;
    transition: transform 0.5s ease, margin 0.5s ease;
    /* เพิ่ม transition ให้ smooth */

    .v-card {
        width: 1000px;
        /* ขนาดเริ่มต้นของ slide */
        transform: scale(0.5);
        /* ลดขนาดของ slide ที่ไม่ active */
        transition: transform 0.5s ease, margin 0.5s ease;
    }

    /* เพิ่ม margin ให้แต่ละ slide เพื่อไม่ให้ซ้อนกัน */
    margin: 0 10px;
    /* เพิ่มระยะห่างระหว่างสไลด์ */
}

.carousel__slide--active {
    flex: 0 0 auto;
    display: flex;
    justify-content: center;
    align-items: center;

    .v-card {
        transform: scale(1);
        /* ขยายขนาดของ slide ที่ active */
    }

    margin: 0 15px;
    /* เพิ่ม margin สำหรับ slide ที่ active */
}
</style>
