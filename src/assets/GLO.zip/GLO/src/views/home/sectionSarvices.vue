<script setup>
import propertyImage from '@/assets/Property34.png';
import book from '@/assets/book1.png';
import file from '@/assets/file.png';
import { Swiper, SwiperSlide } from 'swiper/vue';
import 'swiper/swiper-bundle.css';
import { Pagination } from 'swiper/modules';
</script>

<template>

    <div style="margin-top: 47px; position: relative;z-index: 1;">
      <v-row>
        <v-col cols="12" md="6" sm="12">
          <MainTopic text="โปรโมท" />
          <div class="box-carousel">
            <swiper :pagination="{ clickable: true }" :modules="[Pagination]" class="mySwiper">
              <swiper-slide> <img src="../../assets/promote.png"></img> </swiper-slide>
              <swiper-slide><img src="../../assets/promote1.png"></img></swiper-slide>
            </swiper>
          </div>
        </v-col>
        <v-col cols="12" md="6" sm="12">
          <MainTopic text="บริการของเรา" />
          <v-row>
            <v-col cols="12" md="6" sm="12">
              <CardServices :imageSrc="propertyImage" text="คลังความรู้" details="Lorem ipsum dolor sit amet " />
            </v-col>
            <v-col cols="12" md="6" sm="12">
              <CardServices gradient="linear-gradient(45deg,#05E37B, #01C6BD)" :imageSrc="book" width="141" height="141"
                text="e-Learning" details="Lorem ipsum dolor sit amet " />
            </v-col>
            <v-col cols="12" md="6" sm="12">
              <CardServices gradient="linear-gradient(45deg,#FF9AA7, #FE6A7C)" :imageSrc="propertyImage"
                text="โอกาสแห่งนวัตกรรม" details="Lorem ipsum dolor sit amet " />
            </v-col>
            <v-col cols="12" md="6" sm="12">
              <CardServices :imageSrc="file" text="บริหารโครงการ" width="151" height="141"
                details="Lorem ipsum dolor sit amet " />
            </v-col>
          </v-row>
        </v-col>
      </v-row>
    </div>

</template>


<style lang="scss" scoped>
.box-carousel {
  height: 100%;

  img {
    width: 100%;
    height: 313px;
    border-radius: 12px;
  }

  .swiper-horizontal {
    height: 100%;
  }

  .swiper-pagination {
    bottom: 15px;
  }

  ::v-deep .swiper-pagination-bullet-active {
    background: #FD9B3A !important;
  }
}


</style>